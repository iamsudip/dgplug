#!/usr/bin/env python
"""shell_demo project"""

requirements = []

try:
    from setuptools import setup, find_packages
except ImportError:
    requirements.append('setuptools-0.9.7')

try:
    import requests
except ImportError:
    requirements.append('requests')

try:
    from cmd2 import Cmd
except ImportError:
    requirements.append('cmd2')

setup(name = 'shell_demo',
    version = '0.4',
    description = "A script to run own shell",
    long_description = "A script to run own shell",
    platforms = ["Linux"],
    author = "iam_sudip",
    author_email = "iamsudip@programmer.net",
    url = "https://github.com/iamsudip",
    license = "MIT",
    packages = find_packages(),
    install_requires=requirements,
    scripts=['shell_demo'],
    data_files=[('/usr/bin',['shell_demo']),
    ('/usr/share/shell_demo', ['README'])
    ]
    )
