#!/usr/bin/env python
"""tweetup project"""

requirements = []

try:
    from setuptools import setup, find_packages
except ImportError:
    requirements.append('setuptools')

try:
    import fbconsole
except ImportError:
    requirements.append('fbconsole')

setup(name = 'tweetup',
    version = '0.1',
    description = "A script to upload photo to facebook",
    long_description = "A script to upload photo to facebook",
    platforms = ["Linux"],
    author = "iam_sudip",
    author_email = "iamsudip@programmer.net",
    url = "https://github.com/iamsudip",
    license = "MIT",
    packages = find_packages(),
    install_requires=requirements,
    scripts=['tweetup'],
    data_files=[('/usr/bin',['tweetup']),
    ('/usr/share/shell_demo', ['README.rst'])
    ]
    )
